from flask import Blueprint, request, jsonify
from .models import User, ProviderProfile, JobRequest, Message, Review, db
from werkzeug.security import generate_password_hash, check_password_hash
from flask import current_app
from . import create_app, db

main_bp = Blueprint("main", __name__)

@main_bp.route("/api/register", methods=["POST"])
def register():
    data = request.json
    email = data.get("email")
    password = data.get("password")
    role = data.get("role")
    full_name = data.get("full_name")

    if not all([email, password, role, full_name]):
        return jsonify({"error": "Missing fields"}), 400

    if User.query.filter_by(email=email).first():
        return jsonify({"error": "Email already exists"}), 409

    user = User(
        email=email,
        password_hash=generate_password_hash(password),
        role=role,
        full_name=full_name
    )
    db.session.add(user)
    db.session.commit()

    if role == "provider":
        profile = ProviderProfile(user_id=user.id)
        db.session.add(profile)
        db.session.commit()

    return jsonify({"message": "Registered successfully"}), 201

@main_bp.route("/api/login", methods=["POST"])
def login():
    data = request.json
    email = data.get("email")
    password = data.get("password")

    user = User.query.filter_by(email=email).first()
    if not user or not check_password_hash(user.password_hash, password):
        return jsonify({"error": "Invalid credentials"}), 401

    # For simplicity, return user info (replace with JWT or session in production)
    return jsonify({"id": user.id, "email": user.email, "role": user.role, "full_name": user.full_name}), 200

@main_bp.route("/api/providers", methods=["GET"])
def list_providers():
    providers = ProviderProfile.query.all()
    result = []
    for p in providers:
        result.append({
            "id": p.user.id,
            "full_name": p.user.full_name,
            "bio": p.bio,
            "equipment_specs": p.equipment_specs,
            "pricing_info": p.pricing_info,
            "location": p.location
        })
    return jsonify(result), 200

@main_bp.route("/api/providers/<int:provider_id>", methods=["GET"])
def get_provider(provider_id):
    profile = ProviderProfile.query.filter_by(user_id=provider_id).first()
    if not profile:
        return jsonify({"error": "Provider not found"}), 404
    return jsonify({
        "id": profile.user.id,
        "full_name": profile.user.full_name,
        "bio": profile.bio,
        "equipment_specs": profile.equipment_specs,
        "pricing_info": profile.pricing_info,
        "location": profile.location
    }), 200

@main_bp.route("/api/job_requests", methods=["POST"])
def create_job():
    data = request.json
    customer_id = data.get("customer_id")
    provider_id = data.get("provider_id")
    title = data.get("title")
    description = data.get("description")
    model_file_url = data.get("model_file_url")

    if not all([customer_id, provider_id, title, description]):
        return jsonify({"error": "Missing fields"}), 400

    job = JobRequest(
        customer_id=customer_id,
        provider_id=provider_id,
        title=title,
        description=description,
        model_file_url=model_file_url
    )
    db.session.add(job)
    db.session.commit()
    return jsonify({"message": "Job request created", "job_id": job.id}), 201

@main_bp.route("/api/job_requests/customer/<int:customer_id>", methods=["GET"])
def get_customer_jobs(customer_id):
    jobs = JobRequest.query.filter_by(customer_id=customer_id).all()
    result = []
    for j in jobs:
        result.append({
            "id": j.id,
            "provider_id": j.provider_id,
            "title": j.title,
            "description": j.description,
            "status": j.status,
            "price_offered": str(j.price_offered),
            "created_at": j.created_at
        })
    return jsonify(result), 200

@main_bp.route("/api/job_requests/provider/<int:provider_id>", methods=["GET"])
def get_provider_jobs(provider_id):
    jobs = JobRequest.query.filter_by(provider_id=provider_id).all()
    result = []
    for j in jobs:
        result.append({
            "id": j.id,
            "customer_id": j.customer_id,
            "title": j.title,
            "description": j.description,
            "status": j.status,
            "price_offered": str(j.price_offered),
            "created_at": j.created_at
        })
    return jsonify(result), 200

@main_bp.route("/api/job_requests/<int:job_id>/status", methods=["PUT"])
def update_job_status(job_id):
    data = request.json
    status = data.get("status")
    job = JobRequest.query.get(job_id)
    if not job:
        return jsonify({"error": "Job not found"}), 404
    job.status = status
    db.session.commit()
    return jsonify({"message": "Status updated"}), 200

@main_bp.route("/api/job_requests/<int:job_id>/messages", methods=["POST"])
def post_message(job_id):
    data = request.json
    sender_id = data.get("sender_id")
    content = data.get("content")
    if not all([sender_id, content]):
        return jsonify({"error": "Missing fields"}), 400
    message = Message(job_request_id=job_id, sender_id=sender_id, content=content)
    db.session.add(message)
    db.session.commit()
    return jsonify({"message": "Message sent"}), 201

@main_bp.route("/api/job_requests/<int:job_id>/messages", methods=["GET"])
def get_messages(job_id):
    msgs = Message.query.filter_by(job_request_id=job_id).all()
    result = []
    for m in msgs:
        result.append({
            "id": m.id,
            "sender_id": m.sender_id,
            "content": m.content,
            "created_at": m.created_at
        })
    return jsonify(result), 200

@main_bp.route("/api/job_requests/<int:job_id>/review", methods=["POST"])
def post_review(job_id):
    data = request.json
    reviewer_id = data.get("reviewer_id")
    rating = data.get("rating")
    comment = data.get("comment")
    if not all([reviewer_id, rating]):
        return jsonify({"error": "Missing fields"}), 400
    review = Review(job_request_id=job_id, reviewer_id=reviewer_id, rating=rating, comment=comment)
    db.session.add(review)
    db.session.commit()
    return jsonify({"message": "Review submitted"}), 201
