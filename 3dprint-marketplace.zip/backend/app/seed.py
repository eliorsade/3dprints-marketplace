from app import create_app, db
from app.models import User, ProviderProfile
from werkzeug.security import generate_password_hash

app = create_app()
app.app_context().push()

# Create sample provider
if not User.query.filter_by(email="provider1@example.com").first():
    u = User(
        email="provider1@example.com",
        password_hash=generate_password_hash("secret"),
        role="provider",
        full_name="Alice 3D Prints"
    )
    db.session.add(u)
    db.session.commit()
    prof = ProviderProfile(
        user_id=u.id,
        bio="High-quality SLA and FDM prints.",
        equipment_specs="Formlabs Form 3; Prusa i3 MK3S",
        pricing_info={"per_hour": 50, "per_gram": 0.10},
        location="New York, NY"
    )
    db.session.add(prof)
    db.session.commit()
    print("Seeded provider1@example.com")

# Create sample customer
if not User.query.filter_by(email="customer1@example.com").first():
    c = User(
        email="customer1@example.com",
        password_hash=generate_password_hash("secret"),
        role="customer",
        full_name="Bob Designer"
    )
    db.session.add(c)
    db.session.commit()
    print("Seeded customer1@example.com")
