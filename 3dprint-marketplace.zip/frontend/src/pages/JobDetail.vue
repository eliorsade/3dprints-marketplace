<template>
  <div class="max-w-3xl mx-auto">
    <h2 class="text-2xl font-bold mb-4">Job Detail</h2>
    <!-- Job detail, messages, review section -->
  </div>
</template>
<script>
export default {}
</script>
