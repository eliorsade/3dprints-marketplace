<template>
  <div class="max-w-md mx-auto">
    <h2 class="text-2xl font-bold mb-4">Leave a Review</h2>
    <!-- Review form -->
  </div>
</template>
<script>
export default {}
</script>
