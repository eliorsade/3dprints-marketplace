<template>
  <div class="max-w-md mx-auto">
    <h2 class="text-2xl font-bold mb-4">Request a Job</h2>
    <!-- Form to submit a new job request -->
  </div>
</template>
<script>
export default {}
</script>
