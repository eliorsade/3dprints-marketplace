<template>
  <div class="max-w-3xl mx-auto">
    <h2 class="text-2xl font-bold mb-4">{{ provider.full_name }}</h2>
    <p class="mb-2"><strong>Bio:</strong> {{ provider.bio }}</p>
    <p class="mb-2"><strong>Equipment:</strong> {{ provider.equipment_specs }}</p>
    <p class="mb-2"><strong>Pricing:</strong> {{ provider.pricing_info }}</p>
    <p class="mb-2"><strong>Location:</strong> {{ provider.location }}</p>
  </div>
</template>

<script>
import axios from 'axios'
import { ref, onMounted } from 'vue'

export default {
  props: ['id'],
  setup(props) {
    const provider = ref({})
    const fetchProvider = async () => {
      const res = await axios.get(`/api/providers/${props.id}`)
      provider.value = res.data
    }
    onMounted(fetchProvider)
    return { provider }
  }
}
</script>
