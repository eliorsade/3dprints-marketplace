<template>
  <div>
    <h2 class="text-2xl font-bold mb-4">Messages</h2>
    <!-- Chat window -->
  </div>
</template>
<script>
export default {}
</script>
