<template>
  <div class="max-w-3xl mx-auto">
    <h2 class="text-2xl font-bold mb-4">My Job Requests</h2>
    <!-- List of jobs will go here -->
  </div>
</template>
<script>
export default {}
</script>
