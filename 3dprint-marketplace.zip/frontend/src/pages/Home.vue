<template>
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
    <h1 class="text-3xl font-bold mb-6">Welcome to 3D Printing Marketplace</h1>
    <BrowseProviders />
  </div>
</template>

<script>
import BrowseProviders from './BrowseProviders.vue'
export default {
  components: { BrowseProviders }
}
</script>
