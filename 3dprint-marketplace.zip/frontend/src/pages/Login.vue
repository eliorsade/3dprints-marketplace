<template>
  <div class="max-w-md mx-auto">
    <h2 class="text-2xl font-bold mb-4">Login</h2>
    <form @submit.prevent="handleLogin" class="space-y-4">
      <div>
        <label class="block text-gray-700">Email</label>
        <input v-model="email" type="email" required class="w-full border rounded px-3 py-2" />
      </div>
      <div>
        <label class="block text-gray-700">Password</label>
        <input v-model="password" type="password" required class="w-full border rounded px-3 py-2" />
      </div>
      <button type="submit" class="bg-primary text-white px-4 py-2 rounded">Login</button>
    </form>
  </div>
</template>

<script>
import { useMainStore } from '../store'
import { useRouter } from 'vue-router'

export default {
  setup() {
    const store = useMainStore()
    const router = useRouter()
    const email = ref('')
    const password = ref('')

    const handleLogin = async () => {
      await store.login(email.value, password.value)
      router.push('/')
    }

    return { email, password, handleLogin }
  }
}
</script>
