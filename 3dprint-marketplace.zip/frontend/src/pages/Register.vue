<template>
  <div class="max-w-md mx-auto">
    <h2 class="text-2xl font-bold mb-4">Register</h2>
    <form @submit.prevent="handleRegister" class="space-y-4">
      <div>
        <label class="block text-gray-700">Full Name</label>
        <input v-model="fullName" type="text" required class="w-full border rounded px-3 py-2" />
      </div>
      <div>
        <label class="block text-gray-700">Email</label>
        <input v-model="email" type="email" required class="w-full border rounded px-3 py-2" />
      </div>
      <div>
        <label class="block text-gray-700">Password</label>
        <input v-model="password" type="password" required class="w-full border rounded px-3 py-2" />
      </div>
      <div>
        <label class="block text-gray-700">Role</label>
        <select v-model="role" required class="w-full border rounded px-3 py-2">
          <option value="customer">Customer</option>
          <option value="provider">Provider</option>
        </select>
      </div>
      <button type="submit" class="bg-primary text-white px-4 py-2 rounded">Register</button>
    </form>
  </div>
</template>

<script>
import { useMainStore } from '../store'
import { useRouter } from 'vue-router'
import { ref } from 'vue'

export default {
  setup() {
    const store = useMainStore()
    const router = useRouter()
    const fullName = ref('')
    const email = ref('')
    const password = ref('')
    const role = ref('customer')

    const handleRegister = async () => {
      await store.register({
        full_name: fullName.value,
        email: email.value,
        password: password.value,
        role: role.value
      })
      router.push('/login')
    }

    return { fullName, email, password, role, handleRegister }
  }
}
</script>
