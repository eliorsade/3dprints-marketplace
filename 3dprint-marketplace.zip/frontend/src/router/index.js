import { createRouter, createWebHistory } from 'vue-router'
import Home from '../pages/Home.vue'
import Login from '../pages/Login.vue'
import Register from '../pages/Register.vue'
import BrowseProviders from '../pages/BrowseProviders.vue'
import ProviderProfile from '../pages/ProviderProfile.vue'
import MyJobs from '../pages/MyJobs.vue'
import AssignedJobs from '../pages/AssignedJobs.vue'
import JobDetail from '../pages/JobDetail.vue'

const routes = [
  { path: '/', component: Home },
  { path: '/login', component: Login },
  { path: '/register', component: Register },
  { path: '/providers', component: BrowseProviders },
  { path: '/providers/:id', component: ProviderProfile, props: true },
  { path: '/my-jobs', component: MyJobs },
  { path: '/assigned-jobs', component: AssignedJobs },
  { path: '/jobs/:id', component: JobDetail, props: true }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
