import { defineStore } from 'pinia'
import axios from 'axios'

export const useMainStore = defineStore('main', {
  state: () => ({
    user: null,
    token: null,
    providers: []
  }),
  actions: {
    async fetchProviders() {
      const res = await axios.get('/api/providers')
      this.providers = res.data
    },
    async login(email, password) {
      const res = await axios.post('/api/login', { email, password })
      this.user = res.data
      // Store token logic here if JWT implemented
    },
    async register(data) {
      await axios.post('/api/register', data)
    }
  }
})
